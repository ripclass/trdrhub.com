import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatusBadge } from "@/components/ui/status-badge";
import { 
  FileText, 
  Download, 
  ArrowLeft, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Eye,
  RefreshCw,
  Share2,
  PrinterIcon,
  Clock
} from "lucide-react";

// Mock validation results - replace with real API data
const mockResults = {
  lcNumber: "BD-2024-001",
  status: "completed",
  processedAt: "2024-01-15T14:30:00Z",
  processingTime: "2.3 minutes",
  totalDocuments: 5,
  totalDiscrepancies: 2,
  overallStatus: "warning" as "success" | "error" | "warning",
  documents: [
    {
      id: "1",
      name: "Bill_of_Lading.pdf",
      type: "Bill of Lading",
      status: "success" as const,
      discrepancies: 0,
      extractedFields: {
        vesselName: "MV Bangladesh Express",
        portOfLoading: "Chittagong",
        portOfDischarge: "Hamburg",
        dateOfShipment: "2024-01-10"
      }
    },
    {
      id: "2", 
      name: "Commercial_Invoice.pdf",
      type: "Commercial Invoice",
      status: "error" as const,
      discrepancies: 2,
      extractedFields: {
        invoiceNumber: "INV-2024-001",
        invoiceDate: "2024-01-08",
        totalAmount: "USD 50,000",
        currency: "USD"
      }
    },
    {
      id: "3",
      name: "Packing_List.pdf", 
      type: "Packing List",
      status: "success" as const,
      discrepancies: 0,
      extractedFields: {
        totalPackages: "100",
        grossWeight: "2500 KG",
        netWeight: "2300 KG"
      }
    },
    {
      id: "4",
      name: "Insurance_Certificate.pdf",
      type: "Insurance Certificate", 
      status: "success" as const,
      discrepancies: 0,
      extractedFields: {
        policyNumber: "INS-2024-001",
        insuredAmount: "USD 55,000",
        validUntil: "2024-03-15"
      }
    },
    {
      id: "5",
      name: "Certificate_of_Origin.pdf",
      type: "Certificate of Origin",
      status: "success" as const, 
      discrepancies: 0,
      extractedFields: {
        originCountry: "Bangladesh",
        issuingAuthority: "BGMEA",
        certificateNumber: "COO-2024-001"
      }
    }
  ],
  discrepancies: [
    {
      id: "1",
      documentId: "2",
      documentName: "Commercial_Invoice.pdf",
      severity: "high" as const,
      rule: "UCP 600 Article 18",
      title: "Invoice Date Discrepancy",
      description: "Invoice date (2024-01-08) is earlier than LC issue date (2024-01-10). This violates UCP 600 requirements.",
      suggestion: "Ensure invoice date is on or after the LC issue date. Consider reissuing the invoice with correct date.",
      field: "invoiceDate",
      expected: "On or after 2024-01-10",
      actual: "2024-01-08"
    },
    {
      id: "2", 
      documentId: "2",
      documentName: "Commercial_Invoice.pdf",
      severity: "medium" as const,
      rule: "UCP 600 Article 14",
      title: "Amount Tolerance Issue",
      description: "Invoice amount may exceed LC amount tolerance. Please verify against LC terms.",
      suggestion: "Check if the invoice amount falls within the acceptable tolerance range as specified in the LC.",
      field: "totalAmount", 
      expected: "Within LC tolerance",
      actual: "USD 50,000"
    }
  ]
};

export default function Results() {
  const [searchParams] = useSearchParams();
  const lcNumber = searchParams.get('lc') || mockResults.lcNumber;
  const [activeTab, setActiveTab] = useState("overview");

  const successCount = mockResults.documents.filter(d => d.status === "success").length;
  const errorCount = mockResults.documents.filter(d => d.status === "error").length;
  const successRate = Math.round((successCount / mockResults.totalDocuments) * 100);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/dashboard">
                <Button variant="outline" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="bg-gradient-primary p-2 rounded-lg">
                  <FileText className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">Validation Results</h1>
                  <p className="text-sm text-muted-foreground">LC Number: {lcNumber}</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button variant="outline" size="sm">
                <PrinterIcon className="w-4 h-4 mr-2" />
                Print
              </Button>
              <Button className="bg-gradient-primary hover:opacity-90">
                <Download className="w-4 h-4 mr-2" />
                Download Report
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Status Overview */}
        <Card className="mb-8 shadow-soft border-0">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className={`w-16 h-16 mx-auto mb-3 rounded-full flex items-center justify-center ${
                  mockResults.overallStatus === "success" ? "bg-success/10" :
                  mockResults.overallStatus === "error" ? "bg-destructive/10" : "bg-warning/10"
                }`}>
                  {mockResults.overallStatus === "success" ? (
                    <CheckCircle className="w-8 h-8 text-success" />
                  ) : mockResults.overallStatus === "error" ? (
                    <XCircle className="w-8 h-8 text-destructive" />
                  ) : (
                    <AlertTriangle className="w-8 h-8 text-warning" />
                  )}
                </div>
                <StatusBadge status={mockResults.overallStatus} className="text-sm font-medium">
                  {mockResults.totalDiscrepancies === 0 ? "No Issues Found" : 
                   `${mockResults.totalDiscrepancies} Issues Found`}
                </StatusBadge>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold text-foreground">Processing Summary</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Documents:</span>
                    <span className="font-medium">{mockResults.totalDocuments}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Success Rate:</span>
                    <span className="font-medium text-success">{successRate}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Processing Time:</span>
                    <span className="font-medium">{mockResults.processingTime}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold text-foreground">Validation Results</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-success rounded-full"></div>
                    <span className="text-sm">{successCount} documents passed</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-destructive rounded-full"></div>
                    <span className="text-sm">{errorCount} documents with issues</span>
                  </div>
                  <Progress value={successRate} className="h-2 mt-2" />
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold text-foreground">Next Steps</h3>
                <div className="space-y-2">
                  {mockResults.totalDiscrepancies > 0 ? (
                    <>
                      <Button variant="outline" size="sm" className="w-full">
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Re-upload Fixed Documents
                      </Button>
                      <p className="text-xs text-muted-foreground text-center">
                        Fix discrepancies before submitting to bank
                      </p>
                    </>
                  ) : (
                    <>
                      <Button className="w-full bg-gradient-primary hover:opacity-90" size="sm">
                        <Download className="w-4 h-4 mr-2" />
                        Download LC Package
                      </Button>
                      <p className="text-xs text-success text-center">
                        Ready for bank submission
                      </p>
                    </>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Detailed Results */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="documents">Documents ({mockResults.totalDocuments})</TabsTrigger>
            <TabsTrigger value="discrepancies" className="relative">
              Discrepancies ({mockResults.totalDiscrepancies})
              {mockResults.totalDiscrepancies > 0 && (
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-destructive rounded-full"></div>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Processing Timeline */}
              <Card className="shadow-soft border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Processing Timeline
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-success rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Documents Uploaded</p>
                      <p className="text-xs text-muted-foreground">14:28 - 5 files received</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-success rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">OCR Processing Complete</p>
                      <p className="text-xs text-muted-foreground">14:29 - Text extracted</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-success rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">AI Data Extraction</p>
                      <p className="text-xs text-muted-foreground">14:30 - Fields identified</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-warning rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Compliance Check Complete</p>
                      <p className="text-xs text-muted-foreground">14:30 - 2 issues found</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card className="shadow-soft border-0">
                <CardHeader>
                  <CardTitle>Validation Statistics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-success/5 border border-success/20 rounded-lg">
                      <div className="text-2xl font-bold text-success">{successCount}</div>
                      <div className="text-sm text-muted-foreground">Passed</div>
                    </div>
                    <div className="text-center p-3 bg-destructive/5 border border-destructive/20 rounded-lg">
                      <div className="text-2xl font-bold text-destructive">{errorCount}</div>
                      <div className="text-sm text-muted-foreground">Issues</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>High Priority Issues:</span>
                      <span className="font-medium text-destructive">
                        {mockResults.discrepancies.filter(d => d.severity === "high").length}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Medium Priority Issues:</span>
                      <span className="font-medium text-warning">
                        {mockResults.discrepancies.filter(d => d.severity === "medium").length}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Fields Extracted:</span>
                      <span className="font-medium">23</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="documents" className="space-y-4">
            {mockResults.documents.map((document) => (
              <Card key={document.id} className="shadow-soft border-0">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${
                        document.status === "success" ? "bg-success/10" : "bg-destructive/10"
                      }`}>
                        <FileText className={`w-5 h-5 ${
                          document.status === "success" ? "text-success" : "text-destructive"
                        }`} />
                      </div>
                      <div>
                        <CardTitle className="text-base">{document.name}</CardTitle>
                        <CardDescription>{document.type}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <StatusBadge status={document.status}>
                        {document.discrepancies === 0 ? "Valid" : `${document.discrepancies} Issues`}
                      </StatusBadge>
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4 mr-2" />
                        View
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {Object.entries(document.extractedFields).map(([key, value]) => (
                      <div key={key} className="space-y-1">
                        <p className="text-xs text-muted-foreground font-medium capitalize">
                          {key.replace(/([A-Z])/g, ' $1').trim()}
                        </p>
                        <p className="text-sm font-medium text-foreground">{value}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="discrepancies" className="space-y-4">
            {mockResults.discrepancies.length === 0 ? (
              <Card className="shadow-soft border-0">
                <CardContent className="p-8 text-center">
                  <div className="bg-success/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-success" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">No Discrepancies Found!</h3>
                  <p className="text-muted-foreground">All your LC documents passed validation successfully.</p>
                </CardContent>
              </Card>
            ) : (
              mockResults.discrepancies.map((discrepancy) => (
                <Card key={discrepancy.id} className={`shadow-soft border-0 ${
                  discrepancy.severity === "high" ? "border-l-4 border-l-destructive" : "border-l-4 border-l-warning"
                }`}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={discrepancy.severity === "high" ? "destructive" : "secondary"}>
                            {discrepancy.severity.toUpperCase()} PRIORITY
                          </Badge>
                          <span className="text-sm text-muted-foreground">{discrepancy.rule}</span>
                        </div>
                        <CardTitle className="text-lg text-foreground">{discrepancy.title}</CardTitle>
                        <CardDescription className="mt-2">
                          Document: {discrepancy.documentName}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-secondary/20 p-4 rounded-lg border border-border/50">
                      <h4 className="font-semibold text-foreground mb-2">Issue Description</h4>
                      <p className="text-sm text-muted-foreground">{discrepancy.description}</p>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h5 className="font-semibold text-sm text-foreground mb-2">Expected</h5>
                        <div className="bg-success/5 border border-success/20 p-3 rounded-lg">
                          <p className="text-sm text-success font-mono">{discrepancy.expected}</p>
                        </div>
                      </div>
                      <div>
                        <h5 className="font-semibold text-sm text-foreground mb-2">Found</h5>
                        <div className="bg-destructive/5 border border-destructive/20 p-3 rounded-lg">
                          <p className="text-sm text-destructive font-mono">{discrepancy.actual}</p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-info/5 border border-info/20 p-4 rounded-lg">
                      <h4 className="font-semibold text-info mb-2">💡 Suggested Solution</h4>
                      <p className="text-sm text-muted-foreground">{discrepancy.suggestion}</p>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}