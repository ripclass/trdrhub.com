import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import ExporterDashboard from "./pages/ExporterDashboard";
import ImporterDashboard from "./pages/ImporterDashboard";
import UploadLC from "./pages/UploadLC";
import ExportLCUpload from "./pages/ExportLCUpload";
import ImportLCUpload from "./pages/ImportLCUpload";
import Results from "./pages/Results";
import ExporterResults from "./pages/ExporterResults";
import DraftLCRiskResults from "./pages/DraftLCRiskResults";
import SupplierDocumentResults from "./pages/SupplierDocumentResults";
import ExporterDocumentCorrections from "./pages/ExporterDocumentCorrections";
import DraftLCCorrections from "./pages/DraftLCCorrections";
import SupplierDocumentCorrections from "./pages/SupplierDocumentCorrections";
import Pricing from "./pages/Pricing";
import Support from "./pages/Support";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <TooltipProvider>
          <div className="min-h-screen bg-background">
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/exporter-dashboard" element={<ExporterDashboard />} />
              <Route path="/importer-dashboard" element={<ImporterDashboard />} />
              <Route path="/upload" element={<UploadLC />} />
              <Route path="/export-lc-upload" element={<ExportLCUpload />} />
              <Route path="/import-lc-upload" element={<ImportLCUpload />} />
              <Route path="/results" element={<Results />} />
              <Route path="/exporter-results" element={<ExporterResults />} />
              <Route path="/draft-lc-risk-results" element={<DraftLCRiskResults />} />
              <Route path="/supplier-document-results" element={<SupplierDocumentResults />} />
              <Route path="/exporter-document-corrections" element={<ExporterDocumentCorrections />} />
              <Route path="/draft-lc-corrections" element={<DraftLCCorrections />} />
              <Route path="/supplier-document-corrections" element={<SupplierDocumentCorrections />} />
              <Route path="/pricing" element={<Pricing />} />
              <Route path="/support" element={<Support />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </div>
          <Toaster />
          <Sonner />
        </TooltipProvider>
      </BrowserRouter>
    </QueryClientProvider>
  );
};

export default App;
